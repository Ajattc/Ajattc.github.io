/*

 * ============================================================
 * Theme: Orlando MCO Tram Controller
 * An industrial system that aims to control drivers and sensors, 
 * built to demonstrate real-time emergency and safety driver 
 * operations for a Control Engineer role. 
 * ============================================================
 */

#ifndef WITH_LOAD
#define WITH_LOAD 1
#endif

#ifndef USE_WEBSERVER
#define USE_WEBSERVER 1
#endif

#ifndef PI_DEMO
#define PI_DEMO 0
#endif

#ifndef USE_PI_MUTEX
#define USE_PI_MUTEX 0
#endif

#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "esp_attr.h"
#include "esp_task_wdt.h"

#if USE_WEBSERVER
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_http_server.h"
#include "esp_netif.h"
#include "nvs_flash.h"
#endif




/* ---------- Per-task heartbeat counters (for the monitor) ---------- */
static volatile uint32_t hb_a, hb_b, hb_c, hb_d;
static uint64_t wcet_a_max_us, wcet_b_max_us, wcet_c_max_us, wcet_d_max_us;


#define TRAM_POWER_GPIO GPIO_NUM_21
#define BUTTON_GPIO   GPIO_NUM_18      /* input — button to GND */
#define BUTTON2_GPIO   GPIO_NUM_17      /* input — button to GND */
#define DEBOUNCE_US   100000



/* ---------- Configuration ---------- */
#define LED_GPIO          GPIO_NUM_2
#define SENSOR_GPIO          GPIO_NUM_40
#define HTTP_PORT         80

#define WIFI_SSID         "Wokwi-GUEST"
#define WIFI_PASS         ""             /* Wokwi virtual AP is open */

#define CONFIG_LOG_DEFAULT_LEVEL_INFO 1
#define CONFIG_LOG_MAXIMUM_LEVEL  5


static const char *TAG = "App4";

/* ---------- Synchronization primitives ---------- */
static SemaphoreHandle_t btn_sem;       /* binary — ISR → responder */
static SemaphoreHandle_t btn2_sem;       /* binary — ISR → responder */
static SemaphoreHandle_t pool_sem;      /* counting — N=3 (resource pool) */
static SemaphoreHandle_t shared_mux;    /* mutex — protect shared_state */

/* Signaling primitives */


/* Latency telemetry */
static volatile int64_t isr_entry_time_us;
static volatile uint32_t presses_observed;
static volatile uint64_t latency_max_sem_us;
static volatile uint64_t latency_max_notif_us;

/* Debounce — track time of last accepted edge */
static volatile int64_t last_edge_us;

/* Shared state: single bool, atomic read on Xtensa.
 * (W6 will teach us why this is the only case where volatile-without-mutex is OK.) */
static volatile bool led_on = false;
static volatile bool close_door = false;
static volatile bool closing,Ebrake = false;

static volatile bool brake = true;
static volatile uint16_t tram_motor_drive = 200;









/* ============================================================
 *  ISR — runs in interrupt context. IRAM_ATTR avoids the
 *  first-execution cache-fill penalty from flash.
 * ============================================================ */
// Define these globally alongside your other volatile variables:
static volatile int64_t last_edge_btn1_us = 0;
static volatile int64_t last_edge_btn2_us = 0;

static void IRAM_ATTR button_isr(void *arg)
{
    // 1. Extract which GPIO pin triggered this interrupt
    uint32_t gpio_num = (uint32_t)arg;
    int64_t now = esp_timer_get_time();

    // 2. Branch logic based on which button was pressed

    //binary semaphore - redf emergency STOP button
    if (gpio_num == BUTTON_GPIO) {
        // Debounce for Button 1
        if (now - last_edge_btn1_us < DEBOUNCE_US) return;
        last_edge_btn1_us = now;
        
            BaseType_t higher_woken = pdFALSE;

    /* 2. Signal via binary semaphore.
     *    Multiple presses while taken can be LOST — binary sem has no count. */
    xSemaphoreGiveFromISR(btn_sem, &higher_woken);

        presses_observed++; 
    } 


    //polling semaphore - Black button
    else if (gpio_num == BUTTON2_GPIO) {
        // Debounce for Button 2
        if (now - last_edge_btn2_us < DEBOUNCE_US) return;
        last_edge_btn2_us = now;
        
                   BaseType_t higher_woken = pdFALSE;
    xSemaphoreGiveFromISR(btn2_sem, &higher_woken);
    }
    gpio_intr_disable(gpio_num);
    // Common tracking (if you still want to track global entry times)
    isr_entry_time_us = now;

    BaseType_t higher_woken = pdFALSE;

    /* Request a context switch on ISR exit if a higher-priority task is ready */
    portYIELD_FROM_ISR(higher_woken);
}

/* ============================================================
 *  Bottom-half task: EMERGENCY STOP!!!
 * ============================================================ */
static void btn_task_sem(void *arg)
{
    for (;;) {
        if (xSemaphoreTake(btn_sem, portMAX_DELAY) == pdTRUE) {
            
            int64_t wake = esp_timer_get_time();
            gpio_intr_enable(BUTTON_GPIO);
            gpio_intr_enable(BUTTON2_GPIO);
            int64_t lat = wake - isr_entry_time_us;

            if ((uint64_t)lat > latency_max_sem_us) latency_max_sem_us = (uint64_t)lat;
            
            //Emergency Stop - send signal to motors to brake gradually over 1.5 s
            Ebrake = true; //this lets control loop know it must apply the stopping algorithm
            tram_motor_drive = 0; //lets rest of software know a stop has occurred
             gpio_set_level(TRAM_POWER_GPIO, tram_motor_drive);//cut power directly to motor drive so tram no longer recieving power

            //control loop is high priority task so it respond quick enough while letting other tasks run.
            ESP_LOGI(TAG, "Emergency Stop press #%lu  latency=%lld us (max=%llu)",
                     (unsigned long)presses_observed,
                     (long long)lat,
                     (unsigned long long)latency_max_sem_us);
        }
    }
}

/* ---------- Pool-consumer task: takes from the counting sem ----------
 * Models a producer/consumer where the pool has 3 slots. */
 /* ============================================================
 *  Pool-consumer task: Collect Sample of Motor Data on VFD
 *  Only 3 Variable Frequency Drives that can take measurements over a given period
 *  allowing motor_control to take too because why not
 * ============================================================ */

static void Motor_data_samp(void *arg)
{
    int id = (int)(uintptr_t)arg;
    for (;;) {
        if (xSemaphoreTake(btn2_sem, portMAX_DELAY) == pdTRUE) {
            
            ESP_LOGI(TAG, "[pool#%d] Initiating Data Sample, Finding VFD slot. . .", id);
            
            gpio_intr_enable(BUTTON_GPIO);
            gpio_intr_enable(BUTTON2_GPIO);

            // 2. CHECK THE POOL: Try to grab a slot from the counting semaphore
            if (xSemaphoreTake(pool_sem, pdMS_TO_TICKS(1000)) == pdTRUE) {
                
                ESP_LOGI(TAG, "[pool#%d] took a slot — working...", id);
                vTaskDelay(pdMS_TO_TICKS(500 + (id * 200)));   // simulated work 
                
                // 3. RELEASE: Hand the slot back to the counting pool
                xSemaphoreGive(pool_sem);
                ESP_LOGI(TAG, "[pool#%d] released slot", id);
                
            } else {
                // Task still safely recycles back to waiting for a button press,
                // leaving the counting semaphore slot counts completely untouched.
                ESP_LOGW(TAG, "[pool#%d] No VFD slot available in 1s — backed off", id);
            }
        }
    }
}

/*
static void Motor_data_samp(void *arg)
{
    int id = (int)(uintptr_t)arg;
    for (;;) {
        if (xSemaphoreTake(btn2_sem, portMAX_DELAY) == pdTRUE) {
            
            ESP_LOGI(TAG, "[pool#%d] Initiating Data Sample, Finding VFD slot. . .", id);
            
            gpio_intr_enable(BUTTON_GPIO);
            gpio_intr_enable(BUTTON2_GPIO);

            // 2. CHECK THE POOL: Try to grab a slot from the counting semaphore
            if (xSemaphoreTake(pool_sem, pdMS_TO_TICKS(1000)) == pdTRUE) {
                
                ESP_LOGI(TAG, "[pool#%d] took a slot — working...", id);
                vTaskDelay(pdMS_TO_TICKS(500 + (id * 200)));   // simulated work 
                
                // 3. RELEASE: Hand the slot back to the counting pool
                xSemaphoreGive(pool_sem);
                ESP_LOGI(TAG, "[pool#%d] released slot", id);
                
            } else {
                // Task still safely recycles back to waiting for a button press,
                // leaving the counting semaphore slot counts completely untouched.
                ESP_LOGW(TAG, "[pool#%d] No VFD slot available in 1s — backed off", id);
            }
        }
    }
}
*/








#if WITH_LOAD
/* ============================================================
 *  BACKGROUND LOAD  (WITH_LOAD = 1)
 * ============================================================
 */


#define MEASURE_WCET(_max_var, _body) do {                       \
    int64_t _t0 = esp_timer_get_time();                          \
    _body;                                                        \
    int64_t _dt = esp_timer_get_time() - _t0;                    \
    if ((uint64_t)_dt > (_max_var)) (_max_var) = (uint64_t)_dt;  \
} while (0)

/* ---------- control_loop/dispatch interlock — runs on Core 1 (Task A) D/T/WCET: 2/10/1.27---------- */
#define A_ITERS 300
#define A_ITERS2 800
static volatile uint32_t a_sink;
static void control_loop(void *arg)
{
    TickType_t last = xTaskGetTickCount();
    const TickType_t period = pdMS_TO_TICKS(10);
    for (;;) {
        hb_a++;
      //  int64_t t = esp_timer_get_time();
       // ESP_LOGI(TAG, "task_a start t=%lld \n", t);
        MEASURE_WCET(wcet_a_max_us, {
        // your task body code here

        if(Ebrake){
                      uint32_t x = a_sink ? a_sink : 0xACE1u;   /* seed from sink (observable) */
            for (int i = 0; i < A_ITERS2; i++) {
                x ^= x << 13; x ^= x >> 17; x ^= x << 5;
            }
            a_sink = x;
        }

        //Using Semaphore for close_door
        if (xSemaphoreTake(shared_mux, portMAX_DELAY) == pdTRUE) {
          bool old = close_door;
        close_door = led_on ? true : false;
        if (old != close_door)  ESP_LOGI(TAG, "[control_loop] close_door %d -> %d", old, close_door);
        xSemaphoreGive(shared_mux);
        }

          static volatile uint32_t a_sink;        // <- defeats DCE
          uint32_t x = a_sink ? a_sink : 0xACE1u; // seed from sink (observable)
          for (int i = 0; i < A_ITERS; i++) {
          x ^= x << 13; x ^= x >> 17; x ^= x << 5;   // xorshift32
          }
        a_sink = x;
        });
      //  t = esp_timer_g
        vTaskDelayUntil(&last, period);
    }
}
/* ---------- door sensor read — runs on Core 1 (Task B) D/T/WCET: 4/50/2.5 ---------- */

#define B_SAMP 16                       /* power of two for the index mask */
#define B_TAPS 20                      /* <= B_SAMP */
static float b_buf[B_SAMP];
static float b_coef[B_TAPS];
static volatile float b_sink;
static void blink_task(void *arg)
{
    TickType_t last = xTaskGetTickCount();
    const TickType_t period = pdMS_TO_TICKS(50);
    for (;;) {
        MEASURE_WCET(wcet_b_max_us, {
            float acc = b_sink;          /* seed from sink (observable) */
            for (int n = 0; n < B_SAMP; n++)
                for (int k = 0; k < B_TAPS; k++)
                    acc += b_buf[(n + B_SAMP - k) & (B_SAMP - 1)] * b_coef[k];
            b_sink = acc;
        });
        hb_b++;
        vTaskDelayUntil(&last, period);
    }
}

/* ---------- motor control — runs on Core 1 (Task C) D/T/WCET: 5/25/3 ---------- */

#define C_ITERS 1024                    /* bytes; raise toward 49152 to lengthen */
static volatile uint32_t c_sink;
static void motor_control(void *arg)
{
/* vTaskDelayUntil is drift-free: we wake on a fixed schedule
     * even if our work took a variable amount of time. */
    TickType_t last_wake_c = xTaskGetTickCount();
    const TickType_t cperiod = pdMS_TO_TICKS(25);
    int start_time=0;
    for (;;) {
        hb_c++;

        MEASURE_WCET(wcet_c_max_us, {
    // your task body code here
        if ((tram_motor_drive <200) && ((hb_c % 8) == 0)) {

          tram_motor_drive += 5;
        }

        if(close_door && (!closing)){
          closing = true;
                   static volatile uint32_t c_sink;        // <- defeats DCE
                   uint32_t x = c_sink ? c_sink : 0xACE1u; // seed from sink (observable)
                   for (int i = 0; i < C_ITERS; i++) {
                   x ^= x << 13; x ^= x >> 17; x ^= x << 5;   // xorshift32
                   }
                 c_sink = x;
                 //Using Semaphore for close_door
                 if (xSemaphoreTake(shared_mux, portMAX_DELAY) == pdTRUE) {
                  bool old = close_door;
                  closing = false;      

                  if (old != close_door)  ESP_LOGI(TAG, "[motor_control] close_door %d -> %d", old, close_door);
                  close_door = false;
                  xSemaphoreGive(shared_mux);
                  }
                 
        }
        else if((!close_door) && (closing)){
                   static volatile uint32_t c_sink;        // <- defeats DCE
                   uint32_t x = c_sink ? c_sink : 0xACE1u; // seed from sink (observable)
                   for (int i = 0; i < C_ITERS; i++) {
                   x ^= x << 13; x ^= x >> 17; x ^= x << 5;   // xorshift32
                   }
                 c_sink = x;

                 if (xSemaphoreTake(shared_mux, portMAX_DELAY) == pdTRUE) {
                  bool old = close_door;
                  closing = false;      
                  
                  if (old != close_door)  ESP_LOGI(TAG, "[motor_control] close_door %d -> %d", old, close_door);
                  close_door = false;
                  xSemaphoreGive(shared_mux);
                  }
                 
        }

      else {
        if (xSemaphoreTake(pool_sem, pdMS_TO_TICKS(1)) == pdTRUE) { //cannot afford to wait

                    static volatile uint32_t c_sink;        // <- defeats DCE
                   uint32_t x = c_sink ? c_sink : 0xACE1u; // seed from sink (observable)
                   for (int i = 0; i < C_ITERS; i++) {
                   x ^= x << 13; x ^= x >> 17; x ^= x << 5;   // xorshift32
                   }
                 c_sink = x;
                  xSemaphoreGive(pool_sem); //give counting semaphore back
        }
        else {
            ESP_LOGW(TAG, "ERROR: motor_control cannot access VFD");
        }
      }
        if (((hb_c - start_time) >= 200) && (start_time)) closing = false;

        });

        vTaskDelayUntil(&last_wake_c, cperiod);
    }
    
}

/* ---------- logging task — runs on Core 1 (Task D) D/T/WCET: 50/200/34.7---------- */

static void logging(void *arg)
{
    TickType_t last = xTaskGetTickCount();
    const TickType_t dperiod = pdMS_TO_TICKS(200);

    for (;;) {

        hb_d++;
        MEASURE_WCET(wcet_d_max_us, {

          if(hb_d % 5 == 0) { // wait for 5 iterations( around 1 s)

        printf("\n=== MCO Airport Tram · 4-task monitor ===\n");
        printf("%-5s %-8s %-9s %-12s %-10s\n",
               "Task", "Period", "Priority", "Iterations", "WCET(us)");


        printf("%-5s %-8s %-9d %-12lu %-10llu    Control\n",
               "A", "10 ms",  15, (unsigned long)hb_a, (unsigned long long)wcet_a_max_us);

        printf("%-5s %-8s %-9d %-12lu %-10llu    Sensor\n",
               "B", "50 ms",  11, (unsigned long)hb_b, (unsigned long long)wcet_b_max_us);

        printf("%-5s %-8s %-9d %-12lu %-10llu    Motor\n",
               "C", "25 ms",   8, (unsigned long)hb_c, (unsigned long long)wcet_c_max_us);

        printf("%-5s %-8s %-9d %-12lu %-10llu    Logging\n",
               "D", "200 ms",  4, (unsigned long)hb_d, (unsigned long long)wcet_d_max_us);
        printf("Iterations should check and grow monotonically, logging WCET may be off due to lower priority\n");
          }

        });
        vTaskDelayUntil(&last, dperiod);
    }
}

/* Fill the load buffers exactly once, off the periodic path. */
static void load_init_buffers(void)
{
    for (int i = 0; i < B_SAMP; i++) b_buf[i]  = (float)((i * 2654435761u) & 0xFFFF) / 65536.0f;
    for (int k = 0; k < B_TAPS; k++) b_coef[k] = 1.0f / (float)B_TAPS;   /* boxcar */

}

static void start_background_load(void)
{
    load_init_buffers();
    /* Rate-monotonic ladder, all on Core 1, mirroring App 2. These priorities
     * are FIXED here (this is a load fixture). Note A=15 outranks your
     * bottom-half tasks (12); B/C/D do not. */
    xTaskCreatePinnedToCore(control_loop, "control", 2048, NULL, 15, NULL, APP_CPU_NUM);
    xTaskCreatePinnedToCore(blink_task, "blink", 2048, NULL, 11, NULL, APP_CPU_NUM);
    xTaskCreatePinnedToCore(motor_control, "motor", 2048, NULL,  8, NULL, APP_CPU_NUM);
    xTaskCreatePinnedToCore(logging, "log", 2048, NULL,  2, NULL, APP_CPU_NUM);
}

#endif /* WITH_LOAD */








#if USE_WEBSERVER
/* ---------- HTTP handler: live JSON state ---------- *
 * Returns: {"on":true|false,"toggles":N}
 * The page polls this 4x per second via fetch() &mdash; far faster and smoother
 * than a meta-refresh full-page reload, and a realistic pattern for embedded
 * dashboards. */
static esp_err_t handle_state(httpd_req_t *req)
{
    char buf[64];
    /* MODIFIED: Added "motor":%u to the JSON payload to transmit tram_motor_drive */
    int n = snprintf(buf, sizeof(buf),
        "{\"on\":%s,\"door\":%s,\"motor\":%u}", 
        led_on ? "true" : "false",
        closing ? "true" : "false",
        tram_motor_drive); /* MODIFIED: Passed the uint16_t variable here */
    httpd_resp_set_type(req, "application/json");
    httpd_resp_set_hdr(req, "Cache-Control", "no-store");
    httpd_resp_send(req, buf, n);
    return ESP_OK;
}


/* ---------- HTTP handler: root page (HTML shell only) ---------- */
static esp_err_t handle_root(httpd_req_t *req)
{
    // FIXED: Increased buffer to 4096 to completely solve string truncation
    char buf[4096]; 
    int n = snprintf(buf, sizeof(buf), 
        "<!DOCTYPE html>"
        "<html lang=\"en\"><head>"
        "<meta charset=\"utf-8\">"
        "<title>MCO Tram, Dispatch Control Monitor</title>"
        "<style>"
        "  body { font-family: -apple-system, sans-serif; background: #FAFAF5; color: #1A1A1A; padding: 2rem; }"
        "  h1 { color: #6B4F09; border-bottom: 3px solid #FFC904; display: inline-block; padding-bottom: 4px; }"
        "  .state { font-size: 2.5em; font-weight: 700; margin: 0.5rem 0; }"
        "  .state.on  { color: #1B6A2E; }"
        "  .state.off { color: #B81829; }"
        "  .state.active { color: #D97706; }" 
        "  .meta { color: #6B4F09; font-variant-numeric: tabular-nums; }"
        "  .dot { display:inline-block; width: 0.6em; height: 0.6em; border-radius: 50%%; margin-right: 0.4em; vertical-align: middle; }"
        "  .dot.on  { background: #1B6A2E; }"
        "  .dot.off { background: #B81829; }"
        "  .dot.active { background: #D97706; }"
        "  table { border-collapse: collapse; margin-top: 15px; background: white; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }"
        "  th, td { padding: 10px 15px; border: 1px solid #E5E7EB; text-align: left; }"
        "  th { background: #F3F4F6; color: #4B5563; }"
        "  .num { font-family: monospace; text-align: right; }"
        "</style></head>"
        "<body>"
        "<h1>MCO Tram Dispatch Status</h1>"
        
        "<p>Dispatch State:</p>"
        "<div id=\"state\" class=\"state off\">"
        "  <span id=\"dot\" class=\"dot off\"></span><span id=\"label\">--</span>"
        "</div>"

        "<p>Physical Door Actuator Status:</p>"
        "<div id=\"door_state\" class=\"state off\">"
        "  <span id=\"door_dot\" class=\"dot off\"></span><span id=\"door_label\">Stationary</span>"
        "</div>"
        
        /* MODIFIED: Added a simple HTML block to render the Tram Motor Drive */
        "<p>Tram Motor Drive:</p>"
        "<div class=\"state\">"
        "  <span id=\"motor_label\" class=\"meta\">0</span>"
        "</div>"
        
        "<h1>MCO Airport Tram · 4-task monitor</h1>"
        "<table>"
        "<thead><tr><th>Task</th><th>Period</th><th>Priority</th><th>Iterations</th><th>WCET (us)</th></tr></thead>"
        "<tbody>"
        /* FIXED: Replaced %%lu / %%llu with active %lu / %llu specifiers to sync with variables below */
        "<tr><td>A</td><td>10 ms</td><td>15</td><td class=\"num\">%lu</td><td class=\"num\">%llu</td></tr>"
        "<tr><td>B</td><td>50 ms</td><td>11</td><td class=\"num\">%lu</td><td class=\"num\">%llu</td></tr>"
        "<tr><td>C</td><td>25 ms</td><td>8</td><td class=\"num\">%lu</td><td class=\"num\">%llu</td></tr>"
        "<tr><td>D</td><td>200 ms</td><td>4</td><td class=\"num\">%lu</td><td class=\"num\">%llu</td></tr>"
        "</tbody></table>"
        "<p class=\"meta\">Polling at 4 Hz via <code>/state</code> JSON endpoint.</p>"
        "<p>Iterations should check and grow monotonically, logged WCET may be off due to lower priority.</p>"

        "<script>"
        "async function poll(){"
        "  try{"
        "    const r = await fetch('/state',{cache:'no-store'});"
        "    const s = await r.json();"
        
        "    const cls = s.on ? 'on' : 'off';"
        "    document.getElementById('state').className = 'state ' + cls;"
        "    document.getElementById('dot').className = 'dot ' + cls;"
        "    document.getElementById('label').textContent = s.on ? 'Ready to Dispatch' : 'Locked (Sensors Active)';"
        
        "    const doorCls = s.door ? 'active' : 'off';"
        "    document.getElementById('door_state').className = 'state ' + doorCls;"
        "    document.getElementById('door_dot').className = 'dot ' + doorCls;"
        "    document.getElementById('door_label').textContent = s.door ? 'Doors Closing / Opening' : 'Doors Fully Open / Stationary';"
        
        /* MODIFIED: Grab the motor variable from the parsed JSON and update the DOM element */
        "    document.getElementById('motor_label').textContent = s.motor;"
        
        "  }catch(e){/* ignore transient network blips */}"
        "}"
        "setInterval(poll, 250);"
        "poll();"
        "</script>"
        "</body></html>",
        (unsigned long)hb_a, (unsigned long long)wcet_a_max_us,
        (unsigned long)hb_b, (unsigned long long)wcet_b_max_us,
        (unsigned long)hb_c, (unsigned long long)wcet_c_max_us,
        (unsigned long)hb_d, (unsigned long long)wcet_d_max_us); 

    httpd_resp_set_type(req, "text/html");
    httpd_resp_send(req, buf, n);
    return ESP_OK;
}

/* ---------- Boilerplate: Wi-Fi + HTTP server ---------- */
static httpd_handle_t start_webserver(void)
{
    httpd_config_t cfg = HTTPD_DEFAULT_CONFIG();
    cfg.server_port = 80;
    cfg.core_id = 0;
    cfg.task_priority = 5;
    cfg.stack_size = 8192;
    httpd_handle_t s = NULL;
    if (httpd_start(&s, &cfg) == ESP_OK) {
        httpd_uri_t root = { .uri="/", .method=HTTP_GET, .handler=handle_root, .user_ctx=NULL };
        httpd_register_uri_handler(s, &root);

        httpd_uri_t state = { .uri="/state", .method=HTTP_GET, .handler=handle_state, .user_ctx=NULL };
        httpd_register_uri_handler(s, &state);
    }
    return s;
}

/* ---------- Wi-Fi event handler ---------- */
static void wifi_event_handler(void *arg, esp_event_base_t base, int32_t id, void *data)
{
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_START) {
        esp_wifi_connect();
    } else if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
        ESP_LOGW(TAG, "Wi-Fi disconnected; reconnecting...");
        esp_wifi_connect();
    } else if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t *event = (ip_event_got_ip_t *)data;
        ESP_LOGI(TAG, "Got IP: " IPSTR, IP2STR(&event->ip_info.ip));
        start_webserver();
    }
}

static void wifi_init_sta(void)
{
    ESP_ERROR_CHECK(nvs_flash_init());
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();

    wifi_init_config_t init_cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&init_cfg));

    ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, &wifi_event_handler, NULL));
    ESP_ERROR_CHECK(esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, &wifi_event_handler, NULL));

    wifi_config_t wifi_cfg = {
        .sta = {
            .ssid = WIFI_SSID,
            .password = WIFI_PASS,
            .threshold.authmode = WIFI_AUTH_OPEN,
        },
    };
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_cfg));
    ESP_ERROR_CHECK(esp_wifi_start());
}
#endif








/* ============================================================
 *  Priority-inversion demo  (tasks H / M / L)
 * ============================================================
 *
 * Classic three-task inversion on one core:
 *   - L (low,  prio 5)  grabs the lock and runs a long CPU-bound section.
 *   - H (high, prio 15) tries the lock shortly after and blocks on it.
 *   - M (mid,  prio 10) becomes ready a little later and burns CPU. It does NOT
 *     touch the lock — it is pure interference.
 *
 * MUTEX mode  (USE_PI_MUTEX=1): when H blocks, L inherits prio 15, so M cannot
 *   preempt L; L finishes its section and hands the lock to H. H's wait is
 *   bounded by L's remaining critical section.
 * BINARY-SEM mode (USE_PI_MUTEX=0): L stays at prio 5; M preempts L while L holds
 *   the lock, so H waits for M to drain too. The wait inflates by M's run time.
 *
 * Read the "[PI][H] ... waited N us" line in each mode; that delta is the lesson.
 */
#if USE_PI_MUTEX
#define PI_LOCK_CREATE() xSemaphoreCreateMutex()
#define PI_LOCK_NAME     "MUTEX (priority inheritance ON)"
#else
#define PI_LOCK_CREATE() xSemaphoreCreateBinary()
#define PI_LOCK_NAME     "BINARY SEM (no inheritance)"
#endif

static SemaphoreHandle_t pi_lock;

/* Stagger knobs — control the ordering, not the durations. */
#define PI_H_DELAY_MS  50      /* H tries the lock 50 ms after start (after L holds it) */
#define PI_M_DELAY_MS  100     /* M becomes ready 100 ms after start */

/* Work knobs — fixed-iteration CPU burns. TUNE on Wokwi using the logged
 * wall-clock durations: aim for L ~500 ms and M ~1000 ms when each runs alone.
 * Absolute values do not affect WHICH mode wins; they set how large the gap is. */
#define PI_L_ITERS  2000000UL
#define PI_M_ITERS  4000000UL

static volatile uint32_t pi_sink;       /* defeats dead-code elimination */
static void pi_burn(uint32_t iters)
{
    uint32_t x = pi_sink ? pi_sink : 1u;
    for (uint32_t i = 0; i < iters; i++) { x ^= (x << 5); x += i; }
    pi_sink = x;
}

static void piL_logging(void *arg)
{
    /* L is created last in app_main, so it grabs the lock immediately. */
    xSemaphoreTake(pi_lock, portMAX_DELAY);
    int64_t t_acq = esp_timer_get_time();
    ESP_LOGI(TAG, "[PI][L] took lock @ %lld us — entering CPU-bound section",
             (long long)t_acq);
    pi_burn(PI_L_ITERS);
    int64_t t_rel = esp_timer_get_time();
    xSemaphoreGive(pi_lock);
    ESP_LOGI(TAG, "[PI][L] released lock @ %lld us (held %lld us wall-clock)",
             (long long)t_rel, (long long)(t_rel - t_acq));
    vTaskDelete(NULL);
}

static void piM_motor_control(void *arg)
{
    vTaskDelay(pdMS_TO_TICKS(PI_M_DELAY_MS));
    int64_t t0 = esp_timer_get_time();
    ESP_LOGI(TAG, "[PI][M] ready @ %lld us — burning CPU (takes no lock)",
             (long long)t0);
    pi_burn(PI_M_ITERS);
    int64_t t1 = esp_timer_get_time();
    ESP_LOGI(TAG, "[PI][M] done  @ %lld us (ran %lld us wall-clock)",
             (long long)t1, (long long)(t1 - t0));
    vTaskDelete(NULL);
}

static void piH_control_loop(void *arg)
{
    vTaskDelay(pdMS_TO_TICKS(PI_H_DELAY_MS));
    int64_t t_block = esp_timer_get_time();
    ESP_LOGI(TAG, "[PI][H] wants lock @ %lld us — blocking", (long long)t_block);
    xSemaphoreTake(pi_lock, portMAX_DELAY);
    int64_t t_acq = esp_timer_get_time();
    int64_t wait = t_acq - t_block;
    ESP_LOGW(TAG, "[PI][H] ACQUIRED @ %lld us — waited %lld us (~%lld ms)  [lock=%s]",
             (long long)t_acq, (long long)wait, (long long)(wait / 1000), PI_LOCK_NAME);
    xSemaphoreGive(pi_lock);
    vTaskDelete(NULL);
}

static void start_inversion_demo(void)
{
    pi_lock = PI_LOCK_CREATE();
#if !USE_PI_MUTEX
    /* A binary semaphore is created empty; prime it once so it starts "unlocked". */
    xSemaphoreGive(pi_lock);
#endif
    ESP_LOGI(TAG, "[PI] inversion demo lock = %s", PI_LOCK_NAME);

    /* Create H and M first (they delay before acting), then L LAST so L wins the
     * lock the instant it is created instead of starving app_main while it burns. */
    xTaskCreatePinnedToCore(piH_control_loop, "H", 4096, NULL, 15, NULL, APP_CPU_NUM);
    xTaskCreatePinnedToCore(piM_motor_control,  "M", 4096, NULL, 10, NULL, APP_CPU_NUM);
    xTaskCreatePinnedToCore(piL_logging,  "L", 4096, NULL,  5, NULL, APP_CPU_NUM);
}



















/* ============================================================
 *  app_main — wire everything up
 * ============================================================ */
void app_main(void)
{
    esp_task_wdt_reconfigure(&(esp_task_wdt_config_t){.timeout_ms = 10000, .idle_core_mask = 0, .trigger_panic = false });
    esp_log_level_set(TAG, ESP_LOG_INFO);
    ESP_LOGI(TAG, "==== App 4 MCO Airport Tram starting — sync quest ====");
    ESP_LOGI(TAG, "Lock mode: %s (USE_PI_MUTEX=%d)", PI_LOCK_NAME, USE_PI_MUTEX);

#if WITH_LOAD
    ESP_LOGI(TAG, "Run mode: UNDER LOAD (WITH_LOAD=1) — 4 tasks on Core 1");
#else
    ESP_LOGI(TAG, "Run mode: IDLE (WITH_LOAD=0) — baseline latency, no background tasks");
#endif

#if USE_WEBSERVER

wifi_init_sta();
#endif


    /* Create signaling primitives. */
    btn_sem = xSemaphoreCreateBinary();
      btn2_sem = xSemaphoreCreateBinary();
      pool_sem   = xSemaphoreCreateBinary();
    shared_mux = xSemaphoreCreateMutex();

        /* Pool consumers — 4 contending for 3 slots */
    for (int i = 1; i <= 4; i++) {
        xTaskCreatePinnedToCore(Motor_data_samp, "pool", 4096,
                                (void*)(uintptr_t)i, 5, NULL, APP_CPU_NUM);
    }
  xSemaphoreGive(pool_sem);
    /* Bottom-half tasks. Both pinned to Core 1, both high priority because
     * they're the "real-time response" path. */
    xTaskCreatePinnedToCore(btn_task_sem,  "Emergency Button",   4096, NULL, 12, NULL, APP_CPU_NUM);

  /*  xTaskCreatePinnedToCore(btn_task_notif,"btn_notif", 4096, NULL, 12,
                           &task_notif_handle, APP_CPU_NUM);*/ 

#if WITH_LOAD
    // Completely disable and deinitialize the Task Watchdog Timer
    esp_task_wdt_deinit();
    /* Bring App 2's periodic tasks online as a Core-1 load fixture. */
    start_background_load();
#endif



    /* Configure GPIOs. */
    gpio_config_t btn_cfg = {
        .pin_bit_mask = 1ULL << BUTTON_GPIO,
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_NEGEDGE,    /* button pulls low when pressed */
    };
    gpio_config_t btn2_cfg = {
        .pin_bit_mask = 1ULL << BUTTON2_GPIO,
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_NEGEDGE,    /* button pulls low when pressed */
    };
    gpio_config(&btn_cfg);
    gpio_config(&btn2_cfg);

    /* Install GPIO ISR service. Flags = 0 means default (low) priority. */
    gpio_install_isr_service(0);
    gpio_isr_handler_add(BUTTON_GPIO, button_isr, (void *)BUTTON_GPIO);
    gpio_isr_handler_add(BUTTON2_GPIO, button_isr, (void *)BUTTON2_GPIO);

gpio_config_t io_conf = { //enable tram power gpio
    .pin_bit_mask = (1ULL << TRAM_POWER_GPIO),
    .mode = GPIO_MODE_OUTPUT,
    .pull_up_en = GPIO_PULLUP_DISABLE,  
    .pull_down_en = GPIO_PULLDOWN_DISABLE, 
    .intr_type = GPIO_INTR_DISABLE
};

    ESP_LOGI(TAG, "Press the button on GPIO %d to initiate E-Stop. \nPress the button GPIO %d to initiate data sample.",
             BUTTON_GPIO, BUTTON2_GPIO);

    /* app_main returns; tasks continue. */

#if PI_DEMO //start demo
    start_inversion_demo();
#endif
}
