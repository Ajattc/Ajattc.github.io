
### Adrian James
### Real-Time Systems(Su26)
### Application 4(FINAL)

# Deliverables
## Wokwi Link
https://wokwi.com/projects/471103920277954561

## Background and Theme related changes
" Application 4 — Synchronization Quest
 Binary Semaphore - Emergency Stop: when ever the red button is pressed an emergency stop task is ran. 
 Top half and bottom half ISR using binary semaphore as a signal to bottom ISR.
 
  Counting Semaphore - VFD Motor Data Sampling: When the black button is pressed, controller gathers a sample
  of the motor data for a small sampling period. This shares the top half ISR and has its own bottom ISR that
  takes 1/3 available VFD slots, which is also needed for Task C: motor_control.
  
  Mutex - close_door state var: added in Task A and Task C for control loop and motor control tasks contolling  
  the close_door boolean state variable, allowing both to manipualate it only if the mutex isnt being held.
 
  Priority Inversion Demo - This is a 3 task H/M/L system added with the large code including webserver, background 
  tasks, and ISRs, however, background tasks(LOAD) must be disabled and webserver(USE_WEBSERVER) should also be disabled."
  
 ## Defense
 Why binary sem for the signal path? What would break if you used counting?
  * For a signal, a binary semaphore is straightforward and simple since it is either available or not available. This
  makes it the most efficient choice for signalling another task to do something. The counting semaphore can log the amount
  of available semaphores and establishes a group with a FIFO system(for this application). If a counting was used instead
  of a binary semaphore, there would be essentially no blocking since a counting semaphore has multiple "slots/tokens"

Why counting sem for the pool? What if you used N binary sems?
 * Using a counting semaphore for the VFD pools allows for a single, differentiable set of semaphores directly tying
 to what is available. If multiple binary semaphores were used, it would require much more work to sort through which 
 semaphore out of the 4 is available instead of a counting, which already knows that SOMETHING is available.

Why mutex for the writers? What if you used a binary sem as a lock?
 * For multiple tasks writing to the same, shared resource(I used task A and C), a mutex is vital to preventing race 
 conditions. Since binary semaphores do not have a locking or "exclusivity" feature for who can set and reset a semaphore,
 they cannot actually block a resource effectively. A higher priority task could theoretically "take" a semaphore that 
 another task is using which could create the same race condition or corrupted memory issue we are trying to prevent.
 
 ## Induced Failure - Counting over binary semaphore(ISR)
 When replacing the counting semaphore used for pooling, I originally predicted that it would force only one task to
 run at a time. This would be because a binary semaphore is binary and can only be available or unavailable for one 
 bit/slot. In reality, NO tasks ran at all since a binary semaphore starts unavailable unless initially given. So,
 I gave the semaphore in the app_main function and got the expected results. Only pool #1 got to have the semaphore
 at any time and the other 3 waited for it to finish indefinitely.

 ## Priority Inversion analysis
 When running the demo with the PIP turned OFF, I noticed that L started first since it was written first, then H, then M.
 This was due tot the delays introduced earlier which caused L to take the mutex and wait almost 4 seconds to finish since it 
 had to wait on M to finish, leading task H to wait on the mutex for 3.6 seconds. When PIP was turned on, task L still started
 first and this time M didnt start until task H finished. This was because task L was running on higher priority temporarily.
 H only had to wait 1.2 seconds this time and only had to wait on task L to finish.

 ## Engineering analysis

1. A mutex actually allows strict blocking of a shared resource, only the task that takes it can release it. A 
binary semaphore can be counteracted or can cause indefinite waiting for the semaphore to be released. This is
because semaphores lack priority inheritance and also lack ownership. In the demo, I lost 2 whole seconds of 
execution time of the high priority task because of priority discrepancies.

2. For the scaffold demo, using 2 counting semaphore slots gives a slightly longer wait time for the 2/4 consumers
waiting on the semaphore. Using 4 counting semaphore slots allows all 4 consumers to use the semaphore any time they
want, meaning no waiting. For my code application, having 4 will still have a delay with whichever task asks for the 
semaphore last.

3. In the screenshot(and the previous paragraph which i am copy-pasting here), H ends up waiting for task L and M to finish
for PIP OFF, and task H only waits on task L to release the mutex for PIP ON. The difference caused L to take the mutex and wait almost 4 seconds to finish since it 
 had to wait on M to finish before releasing the mutex, leading task H to wait on the mutex for 3.6 seconds. When PIP was turned on, task L still started
 first and this time M didnt start until task H finished. This was because task L was running on higher priority temporarily.
 H only had to wait 1.2 seconds this time and only had to wait on task L to finish.

 4.  When replacing the counting semaphore used for pooling, I originally predicted that it would force only one task to
 run at a time. This would be because a binary semaphore is binary and can only be available or unavailable for one 
 bit/slot. In reality, NO tasks ran at all since a binary semaphore starts unavailable unless initially given. So,
 I gave the semaphore in the app_main function and got the expected results. Only pool #1 got to have the semaphore
 at any time and the other 3 waited for it to finish indefinitely. This essentially happened for the first couple iterations
 where task #1 continuously got the semaphore every time right after it released, making it pretty deterministic.

 ## AI Use 
 I used Gemini for generating functions for bottom half ISR and fixing the ISR as a whole for adding the scaffold
 code to the Wokwi project. It also helped with debugging and other questions on content and connection to theme.

 Gemini Chat Link: https://share.gemini.google/WJEaTJ8kQMyw